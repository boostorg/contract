/*! @file dbc_example.cpp
*   @author Antoine Tandin
*   @date 01-Dec-2003
*   @ingroup DesignByContract_UG
*/

#include <dbc.h>

#include <stdio.h>
#include <math.h>
double stupid_sqrt( double& val )
{
#ifdef _DbC_
	DBC_BEGIN
		double _val = val;
		DBC_PRE_BEGIN
		DBC_PRE( val >= 0, val can not be < 0 )
		DBC_PRE_END
		
		DBC_POST_BEGIN
		DBC_POST( val == _val, the argument val has changed )

		char strmessage[256];
		sprintf( strmessage, "val had changed from %f to %f", _val, val );
		DBC_POST_O( val == _val, same post condition but with a message., strmessage )
		DBC_POST_END
	DBC_END
#endif _DbC_

	val++; // raise post condition
	return sqrt( val );
}

#include "classA.h"

int main()
{
	double f1 = -8; // A call with val = -8, raise the precondition.
	double f2 = stupid_sqrt( f1 );

	double f3 = 8; //A call with val = 8 set the result to 3; ie. sqrt(8+1);
	double f4 = stupid_sqrt( f1 );

	AClass ac;
	printf("Call 0,0\n");
	ac.Test( 0, 0 );
	printf("Call 0,1\n");
	ac.Test( 0, 1 );
	printf("Call 1,0\n");
	ac.Test( 1, 0 );
	printf("Call 1,-1\n");	
	ac.Test( 1, -1 );

    char ch = getchar();
	return 0;
}