/*! @defgroup DesignByContract_UG User guide */
/*! @defgroup DesignByContract Design by contract tools
* 
* You can find the things that you should change or redefine for your own use.
*
* Full documentation in @ref DesignByContract_UG
*@{*/

/*! @def _DbC_
* @brief This define sets "Design by Contract" features
*
* You can define #_DbC_ here or in your preprocessor.
* @warning If not set, no conditions will be tested.
*/
#define _DbC_

/*! @addtogroup DesignByContract_UG User guide
* @brief Macros to use for Design By Contract. Activated if #_DbC_ defined.
* @verbatim
DBC_BEGIN		 
	DBC_PRE_BEGIN // start preconditions
	DBC_PRE( boolExp, Description of precondition 1 )
	DBC_PRE_O( boolExp, Description of precondition 2, "Explanation of fail" )
	DBC_PRE_END
	
	DBC_POST_BEGIN // start postconditions
	DBC_POST( boolExp, Description of postcondition 1 )
	DBC_POST_O( boolExp, Description of precondition 2, "Explanation of fail" )
	DBC_POST_END
DBC_END \endverbatim
* \attention Dont forget to define (or undefine)  @ref _DbC_
* \warning Dont forget to open and close blocks.
*
* See this example from \ref dbc_example.cpp :
* \dontinclude dbc_example.cpp
* \skipline stupid_sqrt
* \until }
* And the call of the stupid fonction ...
* \skipline f1
* \until f2
* Or
* \skipline f3
* \until f4
*/

/*****************************************************************************/
/*! @file dbc.h
*   @author Antoine Tandin
*   @date 01-Dec-2003
*   @brief File to include for DbC features.
******************************************************************************/

#pragma once
#include "dbc_core.h"

#if defined(_DbC_) || (defined(DOXYGEN))
/*! @brief Define option mode for break point.*/
enum __DbC_BreakOption {
	no_break, //!< Never break.
	break_on_all, //!< Always break.
	break_on_precondition_only, //!< Break only on preconditions
	break_on_postcondition_only //!< Break only on postconditions
};
extern __DbC_BreakOption __DbC_breakOnError; //!< Breakpoint option see also dbc.cpp. 

//! Callback function when a precondition is raised.
extern void _dbc_pre_test( bool& res, bool exp, const char* StaticConditionDesciption, unsigned int ligne, const char* file, const char* fct = 0, const char* message = 0 );
//! Callback function when a postcondition is raised.
extern void _dbc_post_test( bool& res, bool exp, const char* StaticConditionDesciption, unsigned int ligne, const char* file, const char* fct = 0, const char* message = 0 );
#endif // _DbC_

/*@}*/

/*! @example dbc_example.cpp
* @sa DesignByContract
*
* This is an example of how to use macros defined in dbc.h.
*
*/