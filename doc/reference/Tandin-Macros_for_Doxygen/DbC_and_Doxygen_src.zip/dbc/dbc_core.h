/*! @addtogroup DesignByContract
*@{*/
/*! \defgroup DesignByContract_core Core DbC members.
* 
* You should not change thoses stuff.
*/
/*@}*/
/*@{*/
/*! @file dbc_core.h
*   @author Antoine Tandin
*   @date 01-Dec-2003
*/
#if defined(_DbC_) && (!defined(DOXYGEN))
/*
	Use if _DbC_
*/
#define _DbC_implementation_
#define DBC_CLASS_NAME structDBC
struct DBC_CLASS_NAME {
	long dbc_postblockretaddr;
	long dbc_postblockaddr;
	DBC_CLASS_NAME();
	~DBC_CLASS_NAME();
};

#define DBC_BEGIN 
#define DBC_END __dbc_body :

#define DBC_PRE_BEGIN
#define DBC_PRE_END

#define DBC_POST_BEGIN 	DBC_CLASS_NAME autoDBC;	__asm cmp dword ptr [autoDBC], 0 __asm je __dbc_body
#define DBC_POST_END 	__asm jmp dword ptr [autoDBC];						

#define DBC_PRE( e, StaticConditionDesciption ) {static bool ig=false; _dbc_pre_test( ig, (e), #StaticConditionDesciption, __LINE__, __FILE__, __FUNCTION__, 0 );}
#define DBC_POST( e, StaticConditionDesciption ) {static bool ig=false; _dbc_post_test( ig, (e), #StaticConditionDesciption, __LINE__, __FILE__, __FUNCTION__, 0 );}
#define DBC_PRE_O( e, StaticConditionDesciption, message ) {static bool ig=false; _dbc_pre_test( ig, (e), #StaticConditionDesciption, __LINE__, __FILE__, __FUNCTION__, message );}
#define DBC_POST_O( e, StaticConditionDesciption, message ) {static bool ig=false; _dbc_post_test( ig, (e), #StaticConditionDesciption, __LINE__, __FILE__, __FUNCTION__, message );}

#else // _DbC_
/*********************
	Used if no _DbC_
*********************/
/*! @brief Define start of condition block */
#define DBC_BEGIN if(0){
/*! @brief Define end of condition block */
#define DBC_END }                          
/*! @brief Define start of precondition block */
#define DBC_PRE_BEGIN                     
/*! @brief Define end of precondition block */
#define DBC_PRE_END                       
/*! @brief Define start of postcondition block */
#define DBC_POST_BEGIN                    
/*! @brief Define end of postcondition block */
#define DBC_POST_END                      
/*! @brief Define a precondition 
* @param e expression to be evaluated. If FALSE then raise condition error.
* @param StaticConditionDesciption is a text (without quotes) to explain the condition.
*/
#define DBC_PRE( e, StaticConditionDesciption )             
/*! @brief Define a post condition
* @param e expression to be evaluated. If FALSE then raise condition error.
* @param StaticConditionDesciption is a text (without quotes) to explain the condition.
*/
#define DBC_POST( e, StaticConditionDesciption )            
/*! @brief Define a precondition with a output message 
* @param e expression to be evaluated. If FALSE then raise condition error.
* @param StaticConditionDesciption is a text (without quotes) to explain the condition.
* @param message is a user message to output.
* @sa Implementation of _dbc_pre_test()
*/
#define DBC_PRE_O( e, StaticConditionDesciption, message )  
/*! @brief Define a postcondition with a output message
* @param e expression to be evaluated. If FALSE then raise condition error.
* @param StaticConditionDesciption is a text (without quotes) to explain the condition.
* @param message is a user message to output.
* @sa Implementation of _dbc_post_test()
*/
#define DBC_POST_O( e, StaticConditionDesciption, message ) 
#endif // _DBC_
/*@}*/