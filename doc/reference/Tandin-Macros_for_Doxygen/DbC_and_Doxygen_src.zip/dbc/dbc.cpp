/*! @brief Return true if running with debugger attached
*   @author Tim Chew
*   @see http://www.codeproject.com/debug/debugger.asp
*/
inline bool IsDebuggerAttached()
{
    unsigned long dw;

    __asm
    {
        push eax    // Preserve the registers
        push ecx
        mov eax, fs:[0x18]  // Get the TIB's linear address
        mov eax, dword ptr [eax + 0x30]
        mov ecx, dword ptr [eax]    // Get the whole DWORD
        mov dw, ecx // Save it
        pop ecx // Restore the registers
        pop eax
    }


    // The 3rd byte is the byte we really need to check for the
    // presence of a debugger.
    // Check the 3rd byte
    return (bool)(dw & 0x00010000 ? true : false);

}

/*! \addtogroup DesignByContract */
/*@{*/
/*! @file dbc.cpp
*   @brief Define callback fonction when raise a precondition or a postcondition.
*   @author Antoine Tandin
*   @date 01-Dec-2003
*
* You should change the implementation of the fonctions or add values to #__DbC_BreakOption
*/

#include "dbc.h"
#if defined( _DbC_implementation_ ) || defined (DOXYGEN)

#include <stdio.h>

#ifdef _DEBUG
/*! \hideinitializer*/
__DbC_BreakOption __DbC_breakOnError = break_on_all;
#else // no _DEBUG
/*! \hideinitializer*/
# ifndef WIN32
__DbC_BreakOption __DbC_breakOnError = no_break;
#else
__DbC_BreakOption __DbC_breakOnError = break_on_all;
# endif
#endif // _DEBUG


#ifdef WIN32
#include <windows.h>
inline bool AskBreak(
                   const char* Title,
				   const char* StaticConditionDesciption, //!< Condition description.
				   unsigned int ligne, //!< Line number in file.
				   const char* file, //!< File name.
				   const char* fct, //!< Fonction name from with the condition is tested.
				   const char* message ) //!< User message.
{
    char buff[1024];
    if(fct)
        sprintf( buff, "File : %s Line : %d\nFunction %s\nExpression : %s\n", file, ligne, fct, StaticConditionDesciption );
    else
        sprintf( buff, "File : %s Line : %d\nExpression : %s\n", file, ligne, StaticConditionDesciption );
    if( message )
    {
        strcat( buff, "\n" );
        strcat( buff, message );
        strcat( buff, "\n" );
    }

    int nCode = MessageBox(0, buff, Title,
                MB_TASKMODAL|MB_ICONHAND|MB_OKCANCEL|MB_SETFOREGROUND);

    return (nCode == IDCANCEL);
}
#endif // WIN32

/*!
*   @sa _dbc_post_test()
*/
void _dbc_pre_test(bool&           res, //!< ignore next break ?
                   bool            exp, //!< boolean expression, raise error if false.
				   const char*     StaticConditionDesciption, //!< Condition description.
				   unsigned int    ligne, //!< Line number in file.
				   const char*     file, //!< File name.
				   const char*     fct, //!< Fonction name from with the condition is tested.
				   const char*     message ) //!< User message.
{
	if(!exp) {
		if( fct )
			printf("PRECONDITION FAIL : %s\n in fonction '%s'\n At L.%u in %s\n", StaticConditionDesciption, fct, ligne, file );
		else
			printf("PRECONDITION FAIL : %s\n   At L.%u in %s\n", StaticConditionDesciption, ligne, file );
		if( message )
			printf( " Ouput : %s\n", message );

		switch( __DbC_breakOnError ) {
			case break_on_all :
			case break_on_precondition_only :
            {
                #ifdef WIN32
                if( !res )
                    res = AskBreak( "PRECONDITION FAIL", StaticConditionDesciption, ligne, file, fct, message );
                #endif // WIN32
                if( !res && IsDebuggerAttached() )
                    __asm int 3h
            }
		}
	} // if(!exp)
}

/*!
*   @sa _dbc_pre_test()
*/
void _dbc_post_test(bool&           res, //!< ignore next break ?
                    bool			exp, //!< boolean expression, raise error if false.
				    const char*		StaticConditionDesciption, //!< Condition description.
				    unsigned int	ligne, //!< Line number in file.
				    const char*		file, //!< File name.
				    const char*		fct, //!< Fonction name from with the condition is tested.
				    const char*		message ) //!< User message.

{
	if(!exp) {
		if( fct )
			printf("POSTCONDITION FAIL : %s\n in fonction '%s'\n At L.%u in %s\n", StaticConditionDesciption, fct, ligne, file );
		else
			printf("POSTCONDITION FAIL : %s\n   At L.%u in %s\n", StaticConditionDesciption, ligne, file );
		if( message )
			printf( " Ouput : %s\n", message );

		switch( __DbC_breakOnError ) {
			case break_on_all :
			case break_on_postcondition_only :
            {
                #ifdef WIN32
                if( !res )
                    res = AskBreak( "POSTCONDITION FAIL", StaticConditionDesciption, ligne, file, fct, message );
                #endif // WIN32
                if( !res && IsDebuggerAttached() )
                    __asm int 3h
            }
		}
	}
}
#endif //_DBC_implementation_
/*@}*/