/*! @ingroup DesignByContract_UG
*/
class AClass {
public :
	AClass::AClass() {;}
	int Test( int argA, int argB ); //!< Test function.
};

/*! @mainpage

	\section intro Introduction

	This is a little documentation of DbC toolkit features.
	This tool have been made to use "Design by Contract" with a simple syntax.
	The tool also link "Design by Contract" conditions with doxygen documentation.

	I really try to do that in standard C++ ... but I didn't found any solution but assembly.

	This have been tested (not very much...) on VC6 and VC7.

	If someone ask me to do, I can add invariant stuff.

	@sa http://archive.eiffel.com/doc/manuals/technology/contract/
	@sa Object Oriented Software Construction from Bertrand Meyer

    \section install Doxygen

	In order to uses the macros for doxygen documentation you have to add this code	in your doxyfile.
	@verbatim

	PREDEFINED         = DOXYGEN \
                         "DBC_PRE_BEGIN= " \
                         "DBC_PRE_END= " \
                         "DBC_POST_BEGIN= " \
                         "DBC_POST_END= " \
                         "DBC_BEGIN=/*! " \
                         "DBC_PRE(a) = " \
                         "DBC_POST(a)= " \
                         "DBC_PRE(a,b) =\pre b \code a \endcode" \
                         "DBC_POST(a,b) =\post b \code a \endcode" \
                         "DBC_PRE_O(a,b,c) =\pre b \code a \endcode" \
                         "DBC_POST_O(a,b,c) =\post b \code a \endcode" \
                         "DBC_END= * /" @endverbatim Assume "* /" means end of comments :)
	\author Antoine Tandin (antoine.tandin@free.fr)

	@sa DesignByContract_UG
	@sa Documentation of \ref AClass assuming classA.h and classA.cpp.
*/