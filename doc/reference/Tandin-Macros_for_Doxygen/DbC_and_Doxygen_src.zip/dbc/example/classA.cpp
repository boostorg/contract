#include "classA.h"
#include "dbc.h"

#include <stdio.h>

bool ChechDataFct( int a, int b ){
	return false;
}

/*! 
	This is a test function.
	
	@return stupid stuff... :)
*/
int AClass::Test(
		int argA, //!< first argument.
		int argB  //!< second argument
		)
{
	DBC_BEGIN
		DBC_PRE_BEGIN
		DBC_PRE( argA >= 0, precond 1 )
		DBC_PRE( argB != 0, precond 2 )
		DBC_PRE_END
		
		DBC_POST_BEGIN
		DBC_POST( argA + argB >= 0, post cond 1 )
		DBC_POST( ChechDataFct( argA, argB ), post cond 2 : cf. ChechDataFct() )
		DBC_POST_END
	DBC_END

	if( argA )
	{
		argA = 0;
		return argB;
	}
	
	if( argB )
	{
		argB = 0;
		return argA;
	}

	return argA + argB;
}