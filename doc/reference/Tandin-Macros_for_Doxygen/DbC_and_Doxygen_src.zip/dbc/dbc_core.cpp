/*! @addtogroup DesignByContract_core */
/*@{*/
/*! @file dbc_core.cpp 
*   @author Antoine Tandin
*   @date 01-Dec-2003
*/
#include "dbc.h"

#ifdef _DbC_implementation_
__declspec(naked) DBC_CLASS_NAME::DBC_CLASS_NAME(){	
	__asm push ebp;
	__asm mov ebp, esp;
	__asm mov eax, ebp;
	__asm add eax, 4;
	__asm mov eax, [eax];
	__asm mov dword ptr [ecx+4], eax;
	__asm mov esp, ebp;
	__asm pop ebp;

	__asm mov dword ptr [ecx], 0 // reset dbc_postblockretaddr

	__asm ret;
}

__declspec(naked) DBC_CLASS_NAME::~DBC_CLASS_NAME(){
	__asm push ebp;
	__asm mov ebp, esp;
	__asm pusha;
	__asm mov eax, ebp;
	__asm add eax, 4;
	__asm mov eax, [eax];
	__asm mov [ecx], eax;
	__asm popa;
	__asm mov esp, ebp;
	__asm pop ebp;
	__asm add esp, 4;
	__asm jmp dword ptr [ecx+4];
}

#endif //_DBC_implementation_
/*@}*/