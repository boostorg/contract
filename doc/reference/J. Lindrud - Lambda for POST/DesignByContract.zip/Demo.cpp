
#include "PrePostCondition.h"

namespace Demo {

	class Rectangle
	{
	public:
		Rectangle(double x1, double y1, double x2, double y2) :
			x1(x1), 
			y1(y1), 
			x2(x2), 
			y2(y2)
		{
			PRECONDITION(1);
			POSTCONDITION(1);
		}


		double width()
		{
			return x2-x1;
		}

		double height()
		{
			return y2-y1;
		}

		void zoom(double factor)
		{
			PRECONDITION( factor > 0 )(factor);
			POSTCONDITION( POST(width) == width()*factor )(width())(factor)(POST(width));
			POSTCONDITION( POST(height) == height()*factor )(height())(factor)(POST(height));

			// Implementation
			// ...
		}

		void translate(double dx, double dy)
		{
			PRECONDITION(1);
			POSTCONDITION( POST(x1) == x1+dx )(x1)(POST(x1))(dx);
			POSTCONDITION( POST(y1) == y1+dy )(y1)(POST(y1))(dy);
			POSTCONDITION( POST(x2) == x2+dx )(x2)(POST(x2))(dx);
			POSTCONDITION( POST(y2) == y2+dy )(y2)(POST(y2))(dy);

			// Implementation
			// ...
			
		}

	private:
		double x1;
		double y1;
		double x2;
		double y2;

		BEGIN_INVARIANT(Rectangle)
			DEFINE_INVARIANT( x2 > x1 && y2 > y1 )(x1)(x2)(y1)(y2)
		END_INVARIANT()
	};

} // namespace Demo

int main()
{
	Demo::Rectangle badRectangle(0,0,-1,-1);
	Demo::Rectangle rectangle(0,0,1,1);
	rectangle.zoom(-1);
	rectangle.translate(1,1);
	rectangle.zoom(2);
	rectangle.translate(-5,-5);
	rectangle.zoom(.5);
	return 0;
}
