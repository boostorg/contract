
//*****************************************************************************
// Platform.h - platform specifics
//
// Jarl Lindrud, September 2004.
// jlindrud@hotmail.com .
//
// May be used in any imaginable way. If you modify this file, 
// please remove my name from this notice...
//*****************************************************************************

#ifndef _PLATFORM_H_
#define _PLATFORM_H_


// OS specifics
#if defined(__WINDOWS__) || defined(_WIN32)
#include <windows.h>
namespace Platform { namespace OS {
		inline void OutputDebugString(const char *msg) { ::OutputDebugString(msg); }
		inline int GetCurrentThreadId() { return ::GetCurrentThreadId(); }
} }

#else
#include <iostream>
namespace Platform { namespace OS {
		inline OutputDebugString(const char *msg) { std::cerr << msg; }
		inline GetCurrentThreadId() { return 0; }
} }

#endif


// Compiler specifics
#if defined(_MSC_VER) && !defined(__INTEL_COMPILER)
#define __PLATFORM_COMPILER__COUNTER		__COUNTER__
#define __PLATFORM_COMPILER__FUNCTION		__FUNCTION__
#elif defined(__BORLANDC__)
#define __PLATFORM_COMPILER__COUNTER		__LINE__
#define __PLATFORM_COMPILER__FUNCTION		__FUNC__
#elif defined(__GNUC__)
#define __PLATFORM_COMPILER__COUNTER		__LINE__
#define __PLATFORM_COMPILER__FUNCTION		__func__
#elif defined(__MWERKS__)
#define __PLATFORM_COMPILER__COUNTER		__LINE__
#define __PLATFORM_COMPILER__FUNCTION		__FUNCTION__
#elif defined(__INTEL_COMPILER)
#define __PLATFORM_COMPILER__COUNTER		__LINE__
#define __PLATFORM_COMPILER__FUNCTION		__FUNCTION__
#endif

#endif // ! _PLATFORM_H_
